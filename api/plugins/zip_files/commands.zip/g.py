import OpenTap
from OpenTap import *
from System import String, Double

@attribute(OpenTap.Display("Frequency Span SCPI Instrument", "Instrument driver for frequency span measurements using SCPI commands.", "SCPI Devices"))
class FrequencySpanScpiInstrument(ScpiInstrument):
    def __init__(self):
        super(FrequencySpanScpiInstrument, self).__init__()
        self.Name = "Frequency Span SCPI Instrument"
    
    # Method to set the frequency span
    def set_frequency_span(self, span_value):
        self.Write(f"SENSe:FREQuency:SPAN {span_value}")
    
    # Method to query the current frequency span
    def query_frequency_span(self):
        self.Write("SENSe:FREQuency:SPAN?")
        span = self.Query(Double)
        return span

    # Method to set the current span
    def set_current_span(self, span_value):
        self.Write(f"SOURce:CURRent:SPAN {span_value}")
    
    # Method to query the current span
    def query_current_span(self):
        self.Write("SOURce:CURRent:SPAN?")
        span = self.Query(Double)
        return span

    # Method to set the voltage span
    def set_voltage_span(self, span_value):
        self.Write(f"SOURce:VOLTage:SPAN {span_value}")
    
    # Method to query the voltage span
    def query_voltage_span(self):
        self.Write("SOURce:VOLTage:SPAN?")
        span = self.Query(Double)
        return span

# Example usage of the FrequencySpanScpiInstrument class in a test step
@attribute(OpenTap.Display("Frequency Span Test Step", "Performs frequency span measurements.", "SCPI Test Steps"))
class FrequencySpanTestStep(TestStep):
    
    Instrument = property(FrequencySpanScpiInstrument, None).add_attribute(OpenTap.Display("Instrument", "The SCPI frequency span instrument to use in the step.", "Instruments"))
    
    def __init__(self):
        super(FrequencySpanTestStep, self).__init__()
    
    def Run(self):
        super().Run()
        
        # Set and query frequency span
        self.Instrument.set_frequency_span(1000.0)  # Example frequency span value in Hz
        freq_span = self.Instrument.query_frequency_span()
        self.Log.Info(f"Frequency Span: {freq_span} Hz")
        
        # Set and query current span
        self.Instrument.set_current_span(1.0)  # Example current span value in A
        curr_span = self.Instrument.query_current_span()
        self.Log.Info(f"Current Span: {curr_span} A")
        
        # Set and query voltage span
        self.Instrument.set_voltage_span(10.0)  # Example voltage span value in V
        volt_span = self.Instrument.query_voltage_span()
        self.Log.Info(f"Voltage Span: {volt_span} V")

        # Set verdict
        self.UpgradeVerdict(OpenTap.Verdict.Pass)
import OpenTap
from OpenTap import *
from System import String, Double

# Define the instrument plugin class
@attribute(OpenTap.Display("Chassis Dynamometer SCPI Instrument", "Instrument driver for chassis dynamometer using SCPI commands.", "SCPI Devices"))
class ChassisDynamometerScpiInstrument(ScpiInstrument):
    def __init__(self):
        super(ChassisDynamometerScpiInstrument, self).__init__()
        self.Name = "Chassis Dynamometer SCPI Instrument"
    
    # Method to set up and measure speed
    def measure_speed(self):
        self.Write("SENSe:SPEED?")
        speed = self.Query(Double)
        return speed
    
    # Method to set up and measure force
    def measure_force(self):
        self.Write("SENSe:FORCE?")
        force = self.Query(Double)
        return force
    
    # Method to set source speed
    def set_source_speed(self, speed_value):
        self.Write(f"SOURce:SPEED {speed_value}")
    
    # Method to set source force
    def set_source_force(self, force_value):
        self.Write(f"SOURce:FORCE {force_value}")

# Example usage of the ChassisDynamometerScpiInstrument class in a test step
@attribute(OpenTap.Display("Chassis Dynamometer Test Step", "Performs measurements using chassis dynamometer.", "SCPI Test Steps"))
class ChassisDynamometerTestStep(TestStep):
    
    Instrument = property(ChassisDynamometerScpiInstrument, None).add_attribute(OpenTap.Display("Instrument", "The SCPI chassis dynamometer instrument to use in the step.", "Instruments"))
    
    def __init__(self):
        super(ChassisDynamometerTestStep, self).__init__()
    
    def Run(self):
        super().Run()
        
        # Use the instrument to measure speed and force
        speed = self.Instrument.measure_speed()
        self.Log.Info(f"Measured speed: {speed} units")
        
        force = self.Instrument.measure_force()
        self.Log.Info(f"Measured force: {force} units")
        
        # Set source speed and force for the dynamometer
        self.Instrument.set_source_speed(30.0)  # Example speed value
        self.Instrument.set_source_force(100.0)  # Example force value
        self.Log.Info("Set dynamometer source speed and force.")

        # Set verdict
        self.UpgradeVerdict(OpenTap.Verdict.Pass)
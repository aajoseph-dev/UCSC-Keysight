from opentap import *
from System import Double, String
import OpenTap
import time

@attribute(OpenTap.Display("EDU36311A USB", "A SCPI instrument driver for the EDU36311A USB device.", "EDU36311A USB"))
class EDU36311AUSB(OpenTap.ScpiInstrument):
    
    def __init__(self):
        super(EDU36311AUSB, self).__init__()
        self.log = Trace(self)
        self.Name = "EDU36311A USB"
    
    def GetIdnString(self):
        a = self.ScpiQuery[String]("*IDN?")
        return a
    
    def reset(self):
        self.normalSCPI("*RST")

    # Here you can add specific methods for EDU36311A USB device operations
    # For example, to set the voltage of a power supply channel:
    def setVoltage(self, channel, voltage):
        self.normalSCPI(f":SOURce{channel}:VOLTage {voltage}")

    # You can also add methods to read measurements, such as current or voltage:
    def measureVoltage(self, channel):
        return self.querySCPI(Double, f":MEASure:VOLTage? CHANnel{channel}")

    def measureCurrent(self, channel):
        return self.querySCPI(Double, f":MEASure:CURRent? CHANnel{channel}")

    # Add any additional commands or settings required for this device below

    def opc(self):
        complete = self.ScpiQuery[Double]('*OPC?')
        while complete != 1:
            complete = self.ScpiQuery[Double]('*OPC?')

    def normalSCPI(self, SCPI):
        self.ScpiCommand(SCPI)
        self.opc()
    
    def querySCPI(self, format, SCPI):
        result = self.ScpiQuery[format](SCPI)
        self.opc()
        return result

# Register the instrument so it's recognized by OpenTAP
Instrument = EDU36311AUSB
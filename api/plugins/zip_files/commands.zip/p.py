from opentap import *
from System import String, Double
import OpenTap

# Define the instrument driver class with OpenTAP attributes
@attribute(OpenTap.Display("GenericSCPIInstrument", "An example of a generic SCPI instrument driver using specific SCPI commands.", "SCPI Devices"))
class GenericSCPIInstrument(OpenTap.ScpiInstrument):
    
    def __init__(self):
        super(GenericSCPIInstrument, self).__init__()
        self.log = Trace(self)
        self.Name = "Generic SCPI Device"
    
    def GetIdnString(self):
        idn_string = self.ScpiQuery[String]("*IDN?")
        return idn_string
    
    def reset(self):
        self.normalSCPI("*RST")
    
    # Example command to turn the output on or off
    def set_output_state(self, state):
        if state not in ["ON", "OFF"]:
            raise ValueError("State must be 'ON' or 'OFF'")
        self.normalSCPI(f"OUTPUT:STATE {state}")
    
    # Example command to measure voltage
    def measure_voltage(self):
        voltage = self.querySCPI(Double, "MEASURE:VOLTAGE?")
        return voltage

    # Synchronize operation and wait for completion
    def opc(self):
        complete = self.ScpiQuery[Double]('*OPC?')
        while complete != 1:
            complete = self.ScpiQuery[Double]('*OPC?')

    # Send a normal SCPI command and wait for operation completion
    def normalSCPI(self, SCPI):
        self.ScpiCommand(SCPI)
        self.opc()
    
    # Send a query SCPI command, get the result, and wait for operation completion
    def querySCPI(self, format, SCPI):
        result = self.ScpiQuery[format](SCPI)
        self.opc()
        return result

# Example usage of the GenericSCPIInstrument class in a test step
@attribute(OpenTap.Display("SCPI Command Test Step", "Test step to demonstrate SCPI command usage.", "SCPI Test Steps"))
class SCPICommandTestStep(TestStep):
    
    Instrument = property(GenericSCPIInstrument, None).add_attribute(OpenTap.Display("Instrument", "The SCPI instrument to use in the step.", "Instruments"))
    
    def __init__(self):
        super(SCPICommandTestStep, self).__init__()
    
    def Run(self):
        super().Run()
        
        # Example usage of the instrument's methods
        self.Instrument.reset()
        self.Instrument.set_output_state("ON")
        voltage = self.Instrument.measure_voltage()
        self.log.Info(f"Measured voltage: {voltage} V")
        
        # Set verdict based on the measurement
        if voltage > 1.0:
            self.UpgradeVerdict(OpenTap.Verdict.Pass)
        else:
            self.UpgradeVerdict(OpenTap.Verdict.Fail)
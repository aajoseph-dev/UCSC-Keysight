It seems there is a misunderstanding in the provided context and instructions. The context talks about SCPI data interchange format (DIF) and a living standard of SCPI commands, while the instructions ask for creating an OpenTAP plugin class in Python for a subset of SCPI commands for a given device. However, the device name and the specific subset of commands are not clearly provided.

To align with the instructions, let's create an OpenTAP plugin class in Python for a hypothetical device that handles frequency, current, and voltage spans using SCPI commands. Since OpenTAP is a .NET-based framework, and pythonnet is used to access .NET libraries in Python, we can create a Python class that inherits from `ScpiInstrument` in OpenTAP and adds methods for setting and querying spans.

Please note that the actual SCPI commands to be used in the implementation will depend on the specific device and its documentation. The following example assumes generic SCPI commands for setting and querying frequency, current, and voltage spans:

```python
import OpenTap
from OpenTap import *
import clr

# We need to add references to the types used in the methods
clr.AddReference("System")
from System import Double

@attribute(OpenTap.Display("Generic Span SCPI Instrument", "Instrument driver for span measurements using SCPI commands.", "SCPI Devices"))
class SpanScpiInstrument(ScpiInstrument):
    def __init__(self):
        super(SpanScpiInstrument, self).__init__()
        self.Name = "Generic Span SCPI Instrument"
    
    # Method to set the frequency span
    def set_frequency_span(self, span_value):
        self.Write(f"FREQ:SPAN {span_value}")
    
    # Method to query the current frequency span
    def query_frequency_span(self):
        return self.Query("FREQ:SPAN?", Double)
    
    # Method to set the current span
    def set_current_span(self, span_value):
        self.Write(f"CURR:SPAN {span_value}")
    
    # Method to query the current span
    def query_current_span(self):
        return self.Query("CURR:SPAN?", Double)
    
    # Method to set the voltage span
    def set_voltage_span(self, span_value):
        self.Write(f"VOLT:SPAN {span_value}")
    
    # Method to query the voltage span
    def query_voltage_span(self):
        return self.Query("VOLT:SPAN?", Double)

# Example usage of the SpanScpiInstrument class in a test step
@attribute(OpenTap.Display("Span Test Step", "Performs span measurements.", "SCPI Test Steps"))
class SpanTestStep(TestStep):
    
    Instrument = property(SpanScpiInstrument, None).add_attribute(OpenTap.Display("Instrument", "The SCPI span instrument to use in the step.", "Instruments"))
    
    def __init__(self):
        super(SpanTestStep, self).__init__()
    
    def Run(self):
        super().Run()
        
        # Set and query frequency span
        self.Instrument.set_frequency_span(1000.0)  # Example frequency span value in Hz
        freq_span = self.Instrument.query_frequency_span()
        self.Log.Info(f"Frequency Span: {freq_span} Hz")
        
        # Set and query current span
        self.Instrument.set_current_span(1.0)  # Example current span value in A
        curr_span = self.Instrument.query_current_span()
        self.Log.Info(f"Current Span: {curr_span} A")
        
        # Set and query voltage span
        self.Instrument.set_voltage_span(10.0)  # Example voltage span value in V
        volt_span = self.Instrument.query_voltage_span()
        self.Log.Info(f"Voltage Span: {volt_span} V")

        # Set verdict
        self.UpgradeVerdict(OpenTap.Verdict
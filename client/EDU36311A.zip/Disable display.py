import OpenTap
from OpenTap import *
from System import String, Double, Boolean
import time

@attribute(Display("EDU36311 Power Supply", "SCPI driver for EDU36311 Power Supply", "Power Supply"))
class EDU36311PowerSupply(ScpiInstrument):

    def __init__(self):
        super(EDU36311PowerSupply, self).__init__()
        self.Name = "EDU36311 Power Supply"
        # Additional properties can be defined here

    def GetIdnString(self):
        idn = self.ScpiQuery[String]("*IDN?")
        return idn

    def Reset(self):
        self.SendScpiCommand("*RST")

    def DisableDisplay(self):
        self.SendScpiCommand(":DISPlay:ENABle OFF")

    def EnableDisplay(self):
        self.SendScpiCommand(":DISPlay:ENABle ON")

    def QueryDisplayStatus(self):
        # The query will return a boolean value where True means the display is enabled
        return self.ScpiQuery[Boolean](":DISPlay:ENABle?")

    def SendScpiCommand(self, command):
        self.ScpiCommand(command)
        self.WaitForOperationComplete()

    def WaitForOperationComplete(self):
        complete = self.ScpiQuery[Double]('*OPC?')
        while complete != 1:
            time.sleep(0.1)
            complete = self.ScpiQuery[Double]('*OPC?')

# Example of using the plugin within a Test Step
@attribute(Display("EDU36311 Display Control", "Test step to control the display of EDU36311 Power Supply", "EDU36311 Test Steps"))
@attribute(AllowAnyChild())
class EDU36311DisplayControl(TestStep):
    Instrument = property(EDU36311PowerSupply, None)\
        .add_attribute(Display("Instrument", "The instrument to use in the step.", "Resources"))

    Enable = property(Boolean, True)\
        .add_attribute(Display("Enable Display", "Enable or disable the display.", "Parameter"))

    def __init__(self):
        super(EDU36311DisplayControl, self).__init__()

    def Run(self):
        super().Run()
        if self.Enable:
            self.Instrument.EnableDisplay()
            self.log.Info("Display enabled.")
        else:
            self.Instrument.DisableDisplay()
            self.log.Info("Display disabled.")

        # Query the current status of the display to verify the action
        display_status = self.Instrument.QueryDisplayStatus()
        if display_status == self.Enable:
            self.UpgradeVerdict(Verdict.Pass)
            self.log.Info(f"Display status verified: {'Enabled' if display_status else 'Disabled'}.")
        else:
            self.UpgradeVerdict(Verdict.Fail)
            self.log.Error(f"Display status mismatch: {'Enabled' if display_status else 'Disabled'}.")
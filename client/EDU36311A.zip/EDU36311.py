from opentap import *
from System import Double, String
import OpenTap
import time

@attribute(OpenTap.Display("EDU36311 Power Supply", "SCPI driver for EDU36311 Power Supply.", "EDU36311"))
class EDU36311PowerSupply(OpenTap.ScpiInstrument):
    
    def __init__(self):
        super(EDU36311PowerSupply, self).__init__()
        self.log = Trace(self)
        self.Name = "EDU36311 Power Supply"
    
    def GetIdnString(self):
        idn = self.ScpiQuery[String]("*IDN?")
        return idn
    
    def reset(self):
        self.normalSCPI("*RST")

    def SetVoltage(self, channel, voltage):
        self.normalSCPI(f":SOURce{channel}:VOLTage {voltage}")

    def SetCurrentLimit(self, channel, current):
        self.normalSCPI(f":SOURce{channel}:CURRent {current}")

    def OutputOn(self, channel):
        self.normalSCPI(f":OUTPut{channel} ON")

    def OutputOff(self, channel):
        self.normalSCPI(f":OUTPut{channel} OFF")

    def MeasureVoltage(self, channel):
        voltage = self.querySCPI(Double, f":MEASure:VOLTage? CHANnel{channel}")
        return voltage

    def MeasureCurrent(self, channel):
        current = self.querySCPI(Double, f":MEASure:CURRent? CHANnel{channel}")
        return current
    
    def opc(self):
        complete = self.ScpiQuery[Double]('*OPC?')
        while complete != 1:
            complete = self.ScpiQuery[Double]('*OPC?')

    def normalSCPI(self, SCPI):
        self.ScpiCommand(SCPI)
        self.opc()
    
    def querySCPI(self, format, SCPI):
        result = self.ScpiQuery[format](SCPI)
        self.opc()
        return result
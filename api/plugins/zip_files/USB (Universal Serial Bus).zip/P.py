import sys
import opentap
import clr

# Import necessary .NET types to reference for generic methods
from System import String, Double
from opentap import *
from OpenTap import Instrument, Trace

# Define the plugin class
@attribute(Display("EDU36311A USB", "A SCPI instrument driver for the EDU36311A USB device.", "EDU36311A USB"))
class EDU36311AUSB(ScpiInstrument):
    
    def __init__(self):
        super(EDU36311AUSB, self).__init__()
        self.log = Trace(self)
        self.Name = "EDU36311A USB"
    
    def GetIdnString(self):
        idn = self.ScpiQuery[String]("*IDN?")
        return idn
    
    def Reset(self):
        self.SendScpi("*RST")

    def SetOutputVoltage(self, voltage):
        self.SendScpi(f"SOURce:VOLTage {voltage}")
        self.WaitForOperationComplete()

    def VerifyOutputVoltage(self, expected_voltage):
        actual_voltage = self.QueryScpi(Double, "MEASure:VOLTage?")
        return abs(actual_voltage - expected_voltage) < 0.01  # Tolerance for verification
    
    def WaitForOperationComplete(self):
        complete = self.ScpiQuery[Double]("*OPC?")
        while complete != 1:
            time.sleep(0.1)
            complete = self.ScpiQuery[Double]("*OPC?")

    def SendScpi(self, command):
        self.ScpiCommand(command)
        self.WaitForOperationComplete()

    def QueryScpi(self, format, command):
        result = self.ScpiQuery[format](command)
        self.WaitForOperationComplete()
        return result

# Register the instrument so it's recognized by OpenTAP
Instrument = EDU36311AUSB
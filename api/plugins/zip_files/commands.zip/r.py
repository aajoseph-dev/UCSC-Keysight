Based on the given context and commands, I will create an OpenTAP plugin class for handling a subset of SCPI commands. Note that the context provided is somewhat unclear, so I will focus on creating a generic template that can be expanded upon for specific device commands. I will add functions for the following SCPI commands based on the given documentation:

- SWR calculation
- Group delay calculation
- Unwrapped phase calculation
- Setting the polarity of a channel
- Measurement of resistance

Here is an example OpenTAP plugin class that encapsulates the described functionality:

```python
from opentap import *
from System import String, Double
import OpenTap
import math

@attribute(OpenTap.Display("SCPICommandInstrument", "Instrument driver for specific SCPI commands.", "SCPI Devices"))
class SCPICommandInstrument(OpenTap.ScpiInstrument):
    
    def __init__(self):
        super(SCPICommandInstrument, self).__init__()
        self.Name = "SCPI Command Instrument"
    
    # Function to calculate Standing Wave Ratio (SWR)
    def calculate_swr(self, reflection_coefficient):
        # Ensure reflection_coefficient is within valid range
        if not (-1 <= reflection_coefficient <= 1):
            raise ValueError("Reflection coefficient must be between -1 and 1")
        return (1 + reflection_coefficient) / (1 - reflection_coefficient)
    
    # Function to calculate Group Delay
    def calculate_group_delay(self, phase, frequency):
        if frequency <= 0:
            raise ValueError("Frequency must be positive")
        # Assuming angle units are in radians
        return -phase / (2 * math.pi * frequency)
    
    # Function to unwrap phase
    def calculate_unwrapped_phase(self, y, x):
        return math.atan2(y, x)
    
    # Function to set polarity
    def set_polarity(self, channel, polarity):
        if polarity not in ["NORMAL", "INVERTED"]:
            raise ValueError("Polarity must be 'NORMAL' or 'INVERTED'")
        self.normalSCPI(f"SOURce:DM:POLarity {channel} {polarity}")
    
    # Function to measure resistance
    def measure_resistance(self):
        resistance = self.querySCPI(Double, "MEASure:RESistance?")
        return resistance
    
    # ... other functions for handling different SCPI commands can be added here

# Example usage of the SCPICommandInstrument class in a test step
@attribute(OpenTap.Display("SCPI Command Test Step", "Demonstrates usage of specific SCPI commands in a test step.", "SCPI Test Steps"))
class SCPICommandTestStep(TestStep):
    
    Instrument = property(SCPICommandInstrument, None).add_attribute(OpenTap.Display("Instrument", "The SCPI instrument to use in the step.", "Instruments"))
    
    def __init__(self):
        super(SCPICommandTestStep, self).__init__()
    
    def Run(self):
        super().Run()
        
        # Example usage of the instrument's methods
        self.Instrument.reset()
        
        # Example calculation of SWR
        reflection_coefficient = 0.5  # Example value
        swr = self.Instrument.calculate_swr(reflection_coefficient)
        self.log.Info(f"Calculated SWR: {swr}")
        
        # Example calculation of Group Delay
        phase = math.pi / 4  # Example value in radians
        frequency = 1e9  # Example value in Hz
        group_delay = self.Instrument.calculate_group_delay(phase, frequency)
        self.log.Info(f"Calculated Group Delay: {group_delay} s")
        
        # Example setting of polarity
        self.Instrument.set_polarity(":ALL", "NORMAL")
        
        # Example measurement of resistance
        resistance = self.Instrument.measure_resistance()
        self.log
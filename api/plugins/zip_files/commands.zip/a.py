import clr
import OpenTap
from OpenTap import *
from System import String, Int32

# Assuming pythonnet has been installed and OpenTAP .NET assemblies are accessible
clr.AddReference("OpenTap")
clr.AddReference("System")

@attribute(OpenTap.Display("Generic SCPI Instrument", "Instrument driver for SCPI commands.", "SCPI Devices"))
class GenericScpiInstrument(ScpiInstrument):
    def __init__(self):
        super(GenericScpiInstrument, self).__init__()
        self.Name = "Generic SCPI Instrument"

    def reset(self):
        self.ScpiCommand("*RST")
        
    def query_operation_complete(self):
        return self.ScpiQuery("*OPC?", Int32)
    
    def select_vxi_device(self, device_number):
        self.ScpiCommand(f"VXI:SELect {device_number}")
    
    def read_vxi_register(self, register_number):
        return self.ScpiQuery(f"VXI:REGister:READ? {register_number}", String)

@attribute(OpenTap.Display("SCPI Reset Test Step", "Sends a Reset command to the SCPI instrument.", "SCPI Test Steps"))
class ScpiResetTestStep(TestStep):
    Instrument = property(GenericScpiInstrument, None).add_attribute(OpenTap.Display("Instrument", "The SCPI instrument to use in the step.", "Instruments"))
    
    def __init__(self):
        super(ScpiResetTestStep, self).__init__()
    
    def Run(self):
        super().Run()
        self.Instrument.reset()
        self.Log.Info("Instrument reset command sent.")
        opc = self.Instrument.query_operation_complete()
        if opc == 1:
            self.Log.Info("Instrument operation complete.")
        else:
            self.Log.Info("Instrument operation not complete.")
        self.UpgradeVerdict(OpenTap.Verdict.Pass if opc == 1 else OpenTap.Verdict.Fail)

# You can add more test steps for other SCPI commands as needed.
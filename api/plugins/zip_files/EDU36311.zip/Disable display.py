import OpenTap
from OpenTap import *
from System import String, Boolean

@attribute(Display("EDU36311 Power Supply", "A SCPI instrument driver for the EDU36311 Power Supply.", "Power Supplies"))
class EDU36311PowerSupply(ScpiInstrument):

    def __init__(self):
        super(EDU36311PowerSupply, self).__init__()
        self.Name = "EDU36311 Power Supply"
        # Initialize additional properties if needed

    def GetIdnString(self):
        idn = self.ScpiQuery[String]("*IDN?")
        return idn
    
    def reset(self):
        self.ScpiCommand("*RST")
        self.WaitForOpc()
    
    # Function to disable the display on the EDU36311 Power Supply
    def DisableDisplay(self):
        self.ScpiCommand(":DISP:ENAB OFF")
        self.WaitForOpc()
    
    # Function to enable the display on the EDU36311 Power Supply
    def EnableDisplay(self):
        self.ScpiCommand(":DISP:ENAB ON")
        self.WaitForOpc()
    
    # Function to query the display status of the EDU36311 Power Supply
    def GetDisplayStatus(self):
        display_status = self.ScpiQuery[Boolean](":DISP:ENAB?")
        return display_status

    def WaitForOpc(self):
        """
        Waits for the operation to complete by querying *OPC?
        """
        opc = 0
        while opc != 1:
            opc = self.ScpiQuery[Double]("*OPC?")

    # Additional methods to interact with the instrument can be added here.

# This part is to demonstrate how to use the class in a test step
@attribute(Display("Toggle EDU36311 Display", "Toggle the display of the EDU36311 Power Supply.", "Power Supplies"))
class ToggleEDU36311Display(TestStep):

    Instrument = property(EDU36311PowerSupply, None) \
        .add_attribute(Display("Instrument", "The EDU36311 Power Supply to use in the step.", "Resources"))

    def __init__(self):
        super(ToggleEDU36311Display, self).__init__()

    def Run(self):
        super().Run()  # Required for debugging to work.
        if self.Instrument.GetDisplayStatus():
            self.Instrument.DisableDisplay()
            self.log.Info("Display disabled")
        else:
            self.Instrument.EnableDisplay()
            self.log.Info("Display enabled")
        # Set verdict
        self.UpgradeVerdict(OpenTap.Verdict.Pass)
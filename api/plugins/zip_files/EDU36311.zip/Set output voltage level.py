import OpenTap
from OpenTap import *
from System import String, Double

@attribute(Display("EDU36311 Power Supply", "A SCPI instrument driver for the EDU36311 Power Supply.", "Power Supplies"))
class EDU36311PowerSupply(ScpiInstrument):

    def __init__(self):
        super(EDU36311PowerSupply, self).__init__()
        self.Name = "EDU36311 Power Supply"
        # Initialize additional properties if needed

    def GetIdnString(self):
        idn = self.ScpiQuery[String]("*IDN?")
        return idn
    
    def reset(self):
        self.ScpiCommand("*RST")
        self.WaitForOpc()

    def SetVoltageLevel(self, channel, level_type, level):
        """
        Sets the voltage level of the specified channel with the specified type.
        
        :param channel: Channel to set the voltage level for (e.g., CH1, CH2).
        :param level_type: Type of the voltage level (e.g., TRIGgered, STARt, STOP, BASE, MANual, IMMediate).
        :param level: The value to set for the voltage level.
        """
        self.ScpiCommand(f":SOURce{channel}:VOLTage:LEVel:{level_type} {level}")
        self.WaitForOpc()
    
    def GetVoltageLevelType(self, channel):
        """
        Queries the type of the voltage level for the specified channel.
        
        :param channel: Channel to query the voltage level type for (e.g., CH1, CH2).
        :return: The type of the voltage level.
        """
        level_type = self.ScpiQuery[String](f":SOURce{channel}:VOLTage:POST:TYPE?")
        return level_type

    def SetCurrentLevel(self, channel, level_type, level):
        """
        Sets the current level of the specified channel with the specified type.
        
        :param channel: Channel to set the current level for (e.g., CH1, CH2).
        :param level_type: Type of the current level (e.g., TRIGgered, STARt, STOP, BASE, MANual, IMMediate).
        :param level: The value to set for the current level.
        """
        self.ScpiCommand(f":SOURce{channel}:CURRent:LEVel:{level_type} {level}")
        self.WaitForOpc()
    
    def GetCurrentLevelType(self, channel):
        """
        Queries the type of the current level for the specified channel.
        
        :param channel: Channel to query the current level type for (e.g., CH1, CH2).
        :return: The type of the current level.
        """
        level_type = self.ScpiQuery[String](f":SOURce{channel}:CURRent:POST:TYPE?")
        return level_type

    def WaitForOpc(self):
        """
        Waits for the operation to complete by querying *OPC?
        """
        opc = 0
        while opc != 1:
            opc = self.ScpiQuery[Double]("*OPC?")
    
    # Additional methods to interact with the instrument can be added here.
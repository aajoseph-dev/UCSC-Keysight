import OpenTap
from OpenTap import *
from System import String, Double

@attribute(Display("EDU36311 Power Supply", "SCPI driver for EDU36311 Power Supply", "Power Supply"))
class EDU36311PowerSupply(ScpiInstrument):

    def __init__(self):
        super(EDU36311PowerSupply, self).__init__()
        self.Name = "EDU36311 Power Supply"
        # Additional properties can be defined here

    def GetIdnString(self):
        idn = self.ScpiQuery[String]("*IDN?")
        return idn

    def Reset(self):
        self.SendScpiCommand("*RST")

    def SetVoltageLevel(self, channel, level, mode="IMMediate"):
        if mode.upper() == "TRIGgered":
            self.SendScpiCommand(f"SOURce{channel}:VOLTage:TRIGgered:AMPLitude {level}")
        else:
            self.SendScpiCommand(f"SOURce{channel}:VOLTage:LEVel:{mode}:AMPLitude {level}")

    def QueryVoltageLevel(self, channel, mode="IMMediate"):
        if mode.upper() == "TRIGgered":
            return self.ScpiQuery[Double](f"SOURce{channel}:VOLTage:LEVel:TRIGgered:AMPLitude?")
        else:
            return self.ScpiQuery[Double](f"SOURce{channel}:VOLTage:LEVel:{mode}:AMPLitude?")

    def SetVoltageMode(self, channel, mode):
        self.SendScpiCommand(f"SOURce{channel}:VOLTage:MODE {mode}")

    def QueryVoltageMode(self, channel):
        return self.ScpiQuery[String](f"SOURce{channel}:VOLTage:MODE?")

    def SetVoltageProtection(self, channel, level):
        self.SendScpiCommand(f"SOURce{channel}:VOLTage:PROTection:LEVel {level}")

    def QueryVoltageProtection(self, channel):
        return self.ScpiQuery[Double](f"SOURce{channel}:VOLTage:PROTection:LEVel?")

    def SendScpiCommand(self, command):
        self.ScpiCommand(command)
        self.WaitForOperationComplete()

    def WaitForOperationComplete(self):
        complete = self.ScpiQuery[Double]('*OPC?')
        while complete != 1:
            time.sleep(0.1)
            complete = self.ScpiQuery[Double]('*OPC?')
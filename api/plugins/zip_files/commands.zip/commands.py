from opentap import *
from System import Double, String
import OpenTap
import time

# Define the instrument driver class with OpenTAP attributes
@attribute(OpenTap.Display("GenericSCPIInstrument", "An example of a generic SCPI instrument driver.", "Generic SCPI Device"))
class GenericSCPIInstrument(OpenTap.ScpiInstrument):
    
    def __init__(self):
        super(GenericSCPIInstrument, self).__init__()
        self.log = Trace(self)
        self.Name = "Generic SCPI Device"
    
    def GetIdnString(self):
        idn_string = self.ScpiQuery[String]("*IDN?")
        return idn_string
    
    def reset(self):
        self.normalSCPI("*RST")

    # Define additional methods for specific category commands
    def custom_command_1(self, param):
        self.normalSCPI(f"CUSTOM:CMD1 {param}")

    def custom_command_2(self):
        value = self.querySCPI(Double, "CUSTOM:CMD2?")
        return value

    # Synchronize operation and wait for completion
    def opc(self):
        complete = self.ScpiQuery[Double]('*OPC?')
        while complete != 1:
            complete = self.ScpiQuery[Double]('*OPC?')

    # Send a normal SCPI command and wait for operation completion
    def normalSCPI(self, SCPI):
        self.ScpiCommand(SCPI)
        self.opc()
    
    # Send a query SCPI command, get the result, and wait for operation completion
    def querySCPI(self, format, SCPI):
        result = self.ScpiQuery[format](SCPI)
        self.opc()
        return result